---
external help file: Posh365-help.xml
Module Name: Posh365
online version: 
schema: 2.0.0
---

# ConvertTo-Shared

## SYNOPSIS
Converts a Cloud User Mailbox to a Shared Mailbox, Disables the AD User & Removes any licenses

## SYNTAX

```
ConvertTo-Shared [[-UserToConvert] <String>]
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
ConvertTo-Shared -UserToConvert JSMITH
```

### -------------------------- EXAMPLE 2 --------------------------
```
ConvertTo-Shared -UserToConvert JSMITH@CONTOSO.COM
```

## PARAMETERS

### -UserToConvert
{{Fill UserToConvert Description}}

```yaml
Type: String
Parameter Sets: (All)
Aliases: 

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

